import requests
import argparse
import csv
import time
from datetime import datetime


def fetch_services(session, svc_url, status_mapping, customer):

    payload = {
        "_fdt": "",
        "_tdt": "",
        "_hdnLocationid": "",
        "_srvstatus": None,
        "_cName": "",
        "_pText": "",
        "_advSrch": "",
        "flag": "",
        "refid": "0",
        "dispid": "0",
        "billid": customer["bill_id"],
        "pageNum": "1",
        "pageSize": "1000"
    }

    for attempt in range(3):

        try:

            time.sleep(0.15)

            response = session.post(svc_url, json=payload, timeout=60)

            if response.status_code == 200:

                data = response.json()
                d_list = data.get("d")
                if d_list and len(d_list) > 0:
                    services = d_list[0]
                else:
                    services = []

                if not services:
                    return []

                rows = []
                for svc in services:

                    raw_status = svc.get("SERVICE_STATUS", "")
                    mapped_status = status_mapping.get(raw_status.strip(), raw_status)

                    rows.append({
                        "Location": customer["location"],
                        "Bill Dt": customer["bill_dt"],
                        "VID": customer["vid"],
                        "UHID": customer["uhid"],
                        "Patient Name": customer["patient"],
                        "Service Name": svc.get("SERVICE_NAME"),
                        "Service Status": mapped_status
                    })

                return rows

        except Exception:

            if attempt < 2:
                print(f"Retrying {customer['vid']} ({attempt+2}/3)")
            else:
                print(f"Failed service fetch for {customer['vid']}")

    return []


def main():

    parser = argparse.ArgumentParser(description="Lucid Vendor Extractor")
    parser.add_argument("--fdt", required=True)
    parser.add_argument("--tdt", required=True)

    args = parser.parse_args()

    from_date = args.fdt
    to_date = args.tdt

    parent_api = "https://portal.luciddiagnostics.com/His/Private/Diagnostics/ClientDashBoard.aspx/GetDispatchBoardParentBills"
    service_api = "https://portal.luciddiagnostics.com/His/Private/Diagnostics/ClientDashBoard.aspx/GetWorkOrderResultpagelevel_NEW"

    headers = {
        "accept": "application/json, text/javascript, */*; q=0.01",
        "content-type": "application/json; charset=UTF-8",
        "origin": "https://portal.luciddiagnostics.com",
        "referer": "https://portal.luciddiagnostics.com/His/Private/Diagnostics/ClientDashBoard.aspx",
        "user-agent": "Mozilla/5.0",
        "x-requested-with": "XMLHttpRequest"
    }

    logins = [
        {
            "name": "Wellness_Hospital",
            "cookies": {
                "Moduledocname": "Client DashBoard",
                "ASP.NET_SessionId": "zf3vpedmiokvbao225nxfn1u",
                ".ASPXAUTH": "5DE956C0644D677BCC430309A59F1E86BC162774092FD66C5D0AD669EC3795D37D78A743578E56FDD833D1D0D22EE83754BA569400A09C42E18D09CA6FD516C70F1029F59E15A2624C767CAD4E11AA7ABDBCE2E261A479EFA006A96F9B9637D50B5B814C07105BF49F86BF3E43BC41C81B8A5C72A756007DC59F5FB9495F2E9A9F89B2DCFEFED92CBF35E7D53CD0A08F4155AB50B8632626BB8FDE03E8069C3356427A116F294C20BF72F75FBF63155A098A492B7B7F962E8248CE8C6EDFDE59"
            },
            "locid": "2",
            "cmpid": "3382"
        },
        {
            "name": "Second_Login",
            "cookies": {
                "Moduledocname": "Client DashBoard",
                "ASP.NET_SessionId": "zf3vpedmiokvbao225nxfn1u",
                ".ASPXAUTH": "1F7E19AADD8068CA57B6CFAD4CD9E667710CCE8CAE624FA621C4E9D7844A5D997CD7906759E9F56F5BE15B667515B323AA0C1C074DEF160E489B09286E553FE4F0054F81A7184E35A1866440A95503CE46D4733A687C0496C5A0A42E66616E585EF1A2370AD143335ACD6489EF4321F5D1527F45C842BC9B07A856838668B8AD0F5E21DAA281FED168DB758C326F831714EB8AC83E01645D2748EA9B7DEEBA8884E3798F2354879E7D364335F48CDCE82D7C86C46902CC0872C53C6AEEDE440B"
            },
            "locid": "2",
            "cmpid": "3702"
        }
    ]

    status_mapping = {
        "R": "Result Done",
        "D": "Dispatched",
        "DRC": "Department Received",
        "B": "Registered",
        "A": "Approved"
    }

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"lucid_vendor_data_{timestamp}.csv"

    print("\nStarting Extraction...\n")

    with open(output_file, "w", newline="", encoding="utf-8") as csvfile:

        columns = [
            "Location",
            "Bill Dt",
            "VID",
            "UHID",
            "Patient Name",
            "Service Name",
            "Service Status"
        ]

        writer = csv.DictWriter(csvfile, fieldnames=columns)
        writer.writeheader()

        for index, login in enumerate(logins):

            if index > 0:
                choice = input(
                    f"\nFirst login completed.\nProceed with {login['name']}? (yes/no): "
                ).strip().lower()

                if choice not in ["yes", "y"]:
                    print("Stopping extraction.")
                    break

            print(f"\nProcessing Login: {login['name']}")

            session = requests.Session()
            session.headers.update(headers)
            session.cookies.update(login["cookies"])

            from datetime import timedelta
            start_dt = datetime.strptime(from_date, "%d-%b-%Y")
            end_dt = datetime.strptime(to_date, "%d-%b-%Y")
            
            delta = end_dt - start_dt
            
            for i in range(delta.days + 1):
                current_dt = start_dt + timedelta(days=i)
                current_dt_str = current_dt.strftime("%d-%b-%Y")
                
                print(f"  -> Fetching for Date: {current_dt_str}")
                page_num = 1
                
                while True:

                    payload = {
                        "_fdt": current_dt_str,
                        "_tdt": current_dt_str,
                        "_cName": "",
                        "_pText": "",
                        "_advSrch": "",
                        "locid": login["locid"],
                        "refid": "0",
                        "dispid": "0",
                        "ishtml": "",
                        "srvstat": "",
                        "refdrid": "",
                        "cmpid": login["cmpid"],
                        "barcode": "",
                        "is_franchise": "N",
                        "pageNum": str(page_num),
                        "pageSize": "200"
                    }

                    response = session.post(parent_api, json=payload)

                    if response.status_code != 200:
                        print("Parent API Error:", response.text)
                        break

                    data = response.json()
                    d_list = data.get("d")

                    if not d_list or len(d_list) < 2:
                        break
                    
                    if not d_list[0]:
                        break

                    bills = d_list[0]

                    if not bills:
                        break

                    print(f"     Page {page_num} -> Bills fetched for {current_dt_str}: {len(bills)}")

                    for bill in bills:

                        customer = {
                            "location": login["name"],
                            "bill_dt": bill.get("BILL_DT"),
                            "vid": bill.get("BILL_NO"),
                            "uhid": bill.get("UMR_NO"),
                            "patient": bill.get("DISPLAY_NAME"),
                            "bill_id": bill.get("BILL_ID")
                        }

                        rows = fetch_services(
                            session,
                            service_api,
                            status_mapping,
                            customer
                        )

                        for row in rows:
                            writer.writerow(row)

                    page_num += 1

    print("\nExtraction Completed")
    print(f"File Saved: {output_file}")


if __name__ == "__main__":
    main()